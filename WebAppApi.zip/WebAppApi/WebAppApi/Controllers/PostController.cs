﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAppApi.DAL;
using WebAppApi.Models;
using WebAppApi.ToDoItems;

namespace WebAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PostController : ControllerBase
    {
        private readonly AppDbContext _context;
        public PostController(AppDbContext context)
        {
            _context = context;
        }
        // GET: api/Post
        /// <summary>
        /// For Get all Post with comments
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<List<Post>> Get()
        {
            return _context.Posts.Include(p=>p.Comments).ToList();
        }

        // GET: api/Post/5
        /// <summary>
        /// Get one Post
        /// </summary>
        /// <param name="id">hansinin id-ni istiyirsiz onu yazin</param>
        /// <returns></returns>
        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<Post>> Get(int id)
        {
            Post post =await _context.Posts.FindAsync(id);
            if (post == null) return NotFound();
            return post;
        }

        // POST: api/Post
        /// <summary>
        /// For create post
        /// </summary>
        /// <param name="post"></param>
        /// <returns>void</returns>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Post post)
        {
            if (post.Title == "Kamran")
            {
                return StatusCode(StatusCodes.Status423Locked, new Response { Status = "Error", Message = "Bu ad ola bilmez" });
            } 
            await _context.Posts.AddAsync(post);
            await _context.SaveChangesAsync();
            return StatusCode(StatusCodes.Status200OK,new Response { Status="Success",Message="Post yaradildi"});
        }

        // PUT: api/Post/5
        /// <summary>
        /// For Update Post
        /// </summary>
        /// <param name="id">whichever item you want, you should write its 'Id'</param>
        /// <param name="post"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Post post)
        {
            if (id != post.Id) return BadRequest();
            Post dbPost =await _context.Posts.FindAsync(id);
            if (dbPost == null) return NotFound();

            dbPost.Title = post.Title;
            dbPost.Body = post.Body;
            await _context.SaveChangesAsync();
            return StatusCode(StatusCodes.Status200OK, new Response { Status = "Success", Message = "Updated" });
        }

        // DELETE: api/ApiWithActions/5
        /// <summary>
        /// To delete Post
        /// </summary>
        /// <param name="id">whichever item you want, you should write its 'Id'</param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Post post =await _context.Posts.FindAsync(id);
            if (post == null) return NotFound();
            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();
            return StatusCode(StatusCodes.Status200OK, new Response { Status = "Success", Message = "Deleted" });
        }
    }
}
