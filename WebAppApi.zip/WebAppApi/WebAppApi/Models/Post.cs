﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppApi.Models
{
    public class Post
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Muhammed istiyir")]
        public string Title { get; set; }
        public string Body { get; set; }
        public virtual ICollection<Comment> Comments { get; set; }
    }
}
