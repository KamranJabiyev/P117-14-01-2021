﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppApi.Models;

namespace WebAppApi.DAL
{
    public class AppDbContext:IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        {}

        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Post>().HasData(
                new Post { Id=1,Title="Post1",Body="Post 1 body"},    
                new Post { Id=2,Title="Post2",Body="Post 2 body"},    
                new Post { Id=3,Title="Post3",Body="Post 3 body"}   
            );

            modelBuilder.Entity<Comment>().HasData(
                new Comment { Id = 1, Massage = "Comment1",PostId=1},
                new Comment { Id = 2, Massage = "Comment2", PostId = 1 },
                new Comment { Id = 3, Massage = "Comment3", PostId = 1 },
                new Comment { Id = 4, Massage = "Comment4", PostId = 2 },
                new Comment { Id = 5, Massage = "Comment5", PostId = 3 }
            );
        }
    }
}
